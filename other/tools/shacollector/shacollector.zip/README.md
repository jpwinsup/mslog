# SYNOPSIS shacollector
    Script Name: shacollector.bat
    Purpose:     collect support information logs related to SHA Area. 
    Version:     7.6
    Last Update: 10 May 2022
    Developer:      Shohei Sadashima / Konan Morimoto / Koji Ishida / Norimasa Okawa / Jun Nakayamada / Takahiro Aizawa
    Email-Alias: shsadash / kojii / nookawa / junakaya / taaizawa

## DESCRIPTION
shacollector is a tool that makes it easy to collect data for problem solving which is included in trace logs (ETW), 
performance logs (perfmon or xperf), event logs and a lot of status information related to SHA area (Storage, Cluster and Hyper-V).

## What's New in this Version 7.6
  - v7.6 change wmic and Get-WmiObject to Get-CimInstance. @Norimasa Okawa
## How to use it
First, specify main options (trace, perf and support) and select sub option that specifies the information to collect. 
Then, 'trace' and 'perf' can be specified with 'start' to start and 'stop' to stop log collection. 
The 'support' option collects various status information and logs without specifying 'start' and 'stop'. 
By default, logs are saved in 'c:\mslog', but you can specify the output destination.

## EXAMPLE
* To collect trace log related I/O drivers (storport.sys, classpnp ...). 
  And change the output folder to 'd:\logs'.
 
      shacollector.bat trace storage start d:\logs
      shacollector.bat trace storage stop

* To specify log file size in MB. default size is 4096 MB.

      shacollector.bat trace storage start size 1024 d:\logs
      shacollector.bat trace storage stop

* To collect multiple trace logs (ex. storport and vss). The log files are saved in 'c:\mslog' as the default.

      shacollector.bat trace storport start
      shacollector.bat trace vss start
      shacollector.bat trace storport stop
      shacollector.bat trace vss stop

* To collect trace log (ex. storport) at OS startup.

      shacollector.bat trace storport boot
      <restart OS>
      shacollector.bat trace storport stop
      shacollector.bat trace storport delete

* To collect performance monitor log. The sample interval is 15sec as the default but it can be change.

      shacollector.bat perf perfmon start
      shacollector.bat perf perfmon stop

* To collect performance monitor log at 1 sec as sample interval. And change the output folder to 'd:\logs'.

      shacollector.bat perf perfmon start d:\logs interval 0:0:1
      shacollector.bat perf perfmon stop

* To collect performance monitor log at 1 sec as sample interval. And change the output folder to 'd:\logs' And to specify 7 days as retention days (default 3 days).

      shacollector.bat perf perfmon start d:\logs interval 0:0:1 days 7
      shacollector.bat perf perfmon stop

* To collect xperf log for investigating the cpu load. And change the output folder to 'd:\logs'.

      shacollector.bat perf cpu start d:\logs
      shacollector.bat perf cpu stop

* To specify log file size 4096 MB. default size is 8192 MB.

      shacollector.bat perf cpu start size 4096 d:\logs
      shacollector.bat perf cpu stop

* To collect xperf log for investigating the memory exhaustion. The log files are saved in 'c:\mslog' as the default.

      shacollector.bat perf memory start
      shacollector.bat perf memory stop

* To collect xperf log for investigating the I/O load. The log files are saved in 'c:\mslog' as the default.

      shacollector.bat perf disk start
      shacollector.bat perf disk stop

* To collect all relevant support information logs such as event logs, registry, dik and network configuration and so on. And change the output folder to 'd:\logs'.

      shacollector.bat support all d:\logs

* To collect specific support information logs (disk, network and event logs). 

      shacollector.bat support disk
      shacollector.bat support network
      shacollector.bat support eventlog

## Usage
    shacollector.bat trace [trace option] start size [Maximum log file size in MB (default 4096 MB)] [output folder (default c:\mslog)]
    shacollector.bat trace [trace option] stop
    shacollector.bat trace [trace option] boot size [Maximum log file size in MB (default 4096 MB)] [output folder (default c:\mslog)]
    shacollector.bat trace [trace option] delete
    
    shacollector.bat perf perfmon start [output folder (default c:\mslog)] interval [sample interval [hh:mm:ss] (ex. 00:00:15) default 15sec] days [retention days (default 3 days)]
    shacollector.bat perf cpu start size [Maximum log file size in MB (default 8192 MB)] [output folder (default c:\mslog)]
    shacollector.bat perf cpu stop
    shacollector.bat perf memory start size [Maximum log file size in MB (default 8192 MB)] [output folder (default c:\mslog)] tag "POOL TAG (ex. FMfn)"
    shacollector.bat perf memory stop
    shacollector.bat perf disk start size [Maximum log file size in MB (default 8192 MB)] [output folder (default c:\mslog)]
    shacollector.bat perf disk stop
    shacollector.bat perf delay start size [Maximum log file size in MB (default 8192 MB)] [output folder (default c:\mslog)]
    shacollector.bat perf delay stop
    shacollector.bat perf heap start pid "Process ID (ex. 1234)" enable
    shacollector.bat perf heap start [output folder (default c:\mslog)] pid "Process ID (ex. 1234)" snap
    shacollector.bat perf heap stop
    shacollector.bat perf boot start [output folder (default c:\mslog)] 
    shacollector.bat perf boot stop
    shacollector.bat support all [output folder (default c:\mslog)]
    shacollector.bat support basic [output folder (default c:\mslog)]
    shacollector.bat support [supportlog option] [output folder (default c:\mslog)]

### available trace option:
      storage   collecting storage drivers trace. (ex storport.sys, classpnp.sys ...)
      storport  collecting storport driver trace.
      ntfs      collecting NTFS driver trace.
      usb       collecting USB drivers trace.
      pnp       collecting Plug and Play drivers trace.
      com       collecting COM/COM+ services trace.
      vds       collecting VDS services trace. (Windows Server 2012 or later)
      vss       collecting VSS services trace. (Windows Server 2008 R2 or later)
      wsb       collecting Windows Server Backup modules trace. (Windows Server 2008 R2 or later)
      cdrom     collecting CD/DVD modules trace.
      ata       collecting ATAPort drivers trace.
      fsrm      collecting FSRM drivers trace.
      dedup     collecting Dedup drivers trace. (Windows Server 2012 or later)
      nfs       collecting NFS services trace.
      network   collecting Network driver trace.
      iscsi     collecting iSCSI driver trace.
      csv       collecting CSV drivers trace.
      wmi       collecting WMI services trace.
      rpc       collecting RPC services trace.
      hyper-v   collecting Hyper-V modules trace.
      cluster   collecting Failover Clustering trace (included netft trace).
      space     collecting Storage Space trace.
      storagereplica     collecting Storage Replica trace.
      msdtc     collecting MSDTC trace.
      fltmgr    collecting Filter Manager trace.
      packet    collecting Network Packet Capture. (Windows Server 2008 R2 or later)
      procmon   collecting Process Monitor log of Sysinternals.
      psr       collecting Problems Steps Recorder log. (maxlogsize is 10MB)
      refs      collecting ReFS drivers trace.
      storsvc   collecting Storage Sensor Service trace.

### available performance option:
      perfmon   collecting Performance Monitor log. default sample interval is 15sec. default retention term is 3 days.
      cpu       collecting CPU perf logs with Xperf.
      memory    collecting Memory perf logs with Xperf.
      disk      collecting Disk perf logs with Xperf.
      delay     collecting Delay perf logs with Xperf.
      heap      collectiong Heap performance log with rdrleakdiag.

### available support option:
      all             collecting all support logs.
         included cluster, disk, diskshadow, driverinfo, eventlog, fltmc, fsrm, handle, hyper-v, iscsi, network, nfs, registry, storagereplica, system, setup, taskscheduler, vss
      basic           collecting basic support logs.
         included disk, driverinfo, eventlog, fltmc, network, system, vss
      cluster         collecting cluster information logs.
      disk            collecting disk information logs.
      diskshadow      collecting diskshadow information logs.
      driverinfo      collecting driver information logs.
      drive-space     collecting drive space information logs.
      eventlog        collecting eventlog information logs.
      fltmc           collecting filter driver information logs.
      fsrm            collecting fsrm information logs.
      handle          collecting file handle information.
      hyper-v         collecting hyper-v information logs.
      iscsi           collecting iscsi information logs.
      network         collecting network information logs.
      nfs             collecting nfs information logs.
      registry        collecting registry information logs.
      storagereplica  collecting Storage Replica information logs.
      system          collecting system information logs.
      taskscheduler   collecting task scheduler information logs.
      virtualfc       collecting virtual fc information.
      vss             collecting vss information logs.
      setup           collecting setup information logs.
      fsi             collecting file system information logs.
      crash           generate blue screen of death (BSOD).

### Update History:
    2018/07/30 v1.0 making @Koji Ishida.
    2018/09/21 v1.1 add WinRM event log @Koji Ishida.
    2018/11/12 v1.2 add Hyper-V trace @Koji Ishida.
    2018/11/15 v1.3 add Storage Space trace @Koji Ishida.
    2018/11/19 v1.4 add S2D and Network information @Koji Ishida.
    2018/12/25 v1.5 add setup logs @Koji Ishida
    2019/01/17 v1.6 add mpclaim output @Koji Ishida
    2019/02/18 v1.7 add nfs and storage replica configuration @Koji Ishida
    2019/03/27 v1.8 add Windows Firewall info in Network @Koji Ishida
    2019/03/29 v1.9 add packet capture for boot mode @Koji Ishida
    2019/03/29 v2.0 add diskshadow and autmount log @Koji Ishida
    2019/04/15 v2.1 add get VMQ config @Koji Ishida
    2019/05/27 v2.2 add FailoverClustering-Manager trace and Hyper-V information @Koji Ishida
    2019/05/31 v2.3 implement to check admin authority. @Koji Ishida
    2019/06/04 v2.4 add NFS infomation and iSCSI information @Koji Ishida
    2019/07/03 v2.5 implement to change output folder @Koji Ishida
    2019/07/09 v2.6 fix a bug @Koji Ishida
    2019/09/13 v2.7 implement to get all application and service log files @Koji Ishida
    2019/09/14 v2.8 implement showvminfo for 2008 R2/2012 of Hyper-V @Koji Ishida
    2019/09/15 v2.9 implement procmon/perfmon/xperf @Koji Ishida
    2019/09/20 v3.0 implement dir/du/fsutil/chkdsk/defrag @Jun Nakayamada
    2019/10/01 v3.1 change vmms and vmwp trace log size 64MB to 1GB.
    2019/10/04 v3.2 fix a bug @Jun Nakayamada
    2019/10/10 v3.3 add VSS logs to drive space information logs
    2019/10/16 v3.4 fix a bug for perfmon and disable collecting diskshadow @Koji Ishida
    2019/10/17 v3.5 add crash, handle and netft option @Koji Ishida
    2019/11/01 v3.5 modify vss trace flag to 0x00000fff @Koji Ishida
    2019/11/09 v3.6 modify hyper-v trace and xperf stop behavior @Koji Ishida
    2019/11/10 v3.7 implement to get eventlog files with csv type. modify pefmon/procmon. implement get-virtualfc @Koji Ishida
    2020/01/07 v4.0 new implementation @Koji Ishida
    2020/01/16 v4.1 fix a bug for perfmon @Koji Ishida
    2020/01/17 v4.2 add setup logs for support @Koji Ishida
    2020/01/22 v4.3 add RDMA Activity counter for perfmon @Koji Ishida
    2020/01/23 v4.4 add S2D information for support @Koji Ishida
    2020/01/24 v4.5 add restart task for perfmon @Koji Ishida
    2020/01/24 v4.6 fix the wrong path was specified for perfmon @Koji Ishida
    2020/02/05 v4.7 modify perfmon counter list for perfmon @Koji Ishida
    2020/03/10 v4.8 modify cdrom trace @Koji Ishida
    2020/03/23 v4.9 add support fsi option @Norimasa Okawa
    2020/03/25 v5.0 add perf heap option @Norimasa Okawa
    2020/04/16 v5.1 modify support fsi option @Koji Ishida
    2020/05/07 v5.2 add ntfs trace @Koji Ishida
    2020/05/11 v5.3 implement to avoid double execution of perfmon @Koji Ishida
    2020/05/18 v5.4 implement to avoid double execution of trace @Koji Ishida
    2020/06/18 v5.5 add virtual-fc trace in hyper-v trace @Koji Ishida
    2020/06/29 v5.6 add MSDTC trace @Shohei Sadashima
    2020/07/10 v5.7 fix the data collector set name of hyper-v trace. @Koji Ishida
    2020/07/28 v5.8 add collecting core information for support log  and supports nfs version 4 tracing. @Koji Ishida
    2020/09/01 v5.9 add get-ClusterNode command result @Konan Morimoto
    2020/09/25 v6.0 transport the shacollector version info to the option.txt. @Shohei Sadashima
    2021/03/05 v6.1 implement size option/add filter manager trace/implement boot option for procmon/implement days option for perfmon. @Koji Ishida
    2021/03/24 v6.2 implement add refs driver trace. @Koji Ishida
    2021/04/05 v6.3 fix the handling of perf memory. @Koji Ishida
    2021/04/07 v6.4 modify drive-space logs @Jun Nakayamada, Add folder option to MSDTC trace @Shohei Sadashima 
    2021/05/07 v6.5 add Get-ClusterSharedVolumeState to the cluster infomation. @Shohei Sadashima
    2021/05/28 v6.6 add Get-ClusterQuorum to the cluster infomation. @Shohei Sadashima / Update Tools @Koji Ishida
    2021/07/01 v6.7 add Dynamic Memory for Hyper-V trace @Koji Ishida
    2021/07/07 v6.8 implement EULA @Koji Ishida
    2021/11/17 v6.9 add registry information in perf/disk and add time/data information in option.txt. @Yudong Ma 
    2022/01/20 v7.0 add boot trace for performance log option@Takahiro Aizawa / implement to handle powershell execution policy @Koji Ishida
    2022/01/21 v7.1 add partmgr GUID for storage.bat / add network info for network support log. @Koji Ishida
    2022/02/22 v7.2 refresh WPT files. @Koji Ishida
    2022/02/22 v7.3 delete Zone.Identifier stream. @Koji Ishidaq
    2022/02/25 v7.4 add storsvc trace (Storage Sensor). @Koji Ishida
    2022/03/03 v7.5 add Get-MpPreference in system.bat of support. @Norimasa Okawa
    2022/05/10 v7.6 change wmic and Get-WmiObject to Get-CimInstance. @Norimasa Okawa
    