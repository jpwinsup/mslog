#************************************************
# checkEULA.ps1
# Version 1.0
# Date: 2021/07/07 created by Koji Ishida
# Description: to check EULA
#************************************************
Param([string]$name, [int]$val)

. $env:LIBDIR\ShowEULA.ps1

$eulaAccepted = ShowEULAIfNeeded $name $val

if($eulaAccepted -ne "Yes") {
    "EULA Decliend"
    exit 1
}
"EULA Accepted"
exit 0

# Call ShowEULAIfNeeded from your main entry point, with your tool name (used to maintain 'already accepted' registry value)
# $mode: 
#    0=popup eula if not yet accepted for this tool
#    1=popup eula for display
#    2=silently accept eula
# if the function does not return "Yes" then you should exit
# e.g.
# 
# 
#
# $eulaAccepted = ShowEULAIfNeeded "RDSTracing4" 0
# if($eulaAccepted -ne "Yes")
# {
#     "EULA Declined"
#     exit
# }
# "EULA Accepted"
# ... continue