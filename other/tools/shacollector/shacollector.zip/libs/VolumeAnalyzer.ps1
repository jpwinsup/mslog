<#
.Description
   Analyze drive-space log files which was collected by shacollector

#> 

<#------------------------------------------------------------------
                           Entry Point 
------------------------------------------------------------------#>

<#------------------------------------------------------------------
                             Parameters 
------------------------------------------------------------------#>
Param(
  [Parameter()]
  [String] $Path
)

<#------------------------------------------------------------------
                             FUNCTIONS 
------------------------------------------------------------------#>
# Set encoding
$OutputEncoding = [Text.Encoding]::Default

#Fuction Get-DiskUsageInformation

# Open du-v-priv.txt

# Set File Path For Du
$DuVPrivFile = Get-ChildItem $Path -include "*du-v-priv.txt" -Recurse | ?{ $_.Length -ne $null } | Select-Object Fullname


# �w�肵���T�u�t�H���_�ɕ�����du-v-priv.txt������Ɖ�͌��ʂ����݂��邽�߁A�G���[�Ƃ���
# �v�f����1�ȊO�Ȃ�G���[�I������
if ($DuVPrivFile.Length -eq 0){
    "Error: There is no data-set."
    exit 
}
if ($DuVPrivFile.Length -gt 1){
    "Error: There are two or more data-set."
    Write-Host "Number of data-set: "  $DuVPrivFile.Length
    exit
}


#Analyze
#Write-Host "===================================="
#Write-Host "Investigating"
#Write-Host "===================================="
$fileName = $DuVPrivFile.Fullname

$file = Get-Content $fileName | Sort-Object -Descending

$ResultDir = Split-Path $fileName -parent

# for resultfile
$date = Get-Date -Format "yyyy-MMdd-HHmmss"
$ResultFile = $ResultDir + "\Du_sort_$date.txt"
$ResultFile2 = $ResultDir + "\AnalysisResult_$date.txt"

Write-Output $file | Out-File -LiteralPath $ResultFile -Encoding Default

$file = Get-Content $fileName | Sort-Object -Descending | select-object  -First 25

# Show analyze results
#Write-Host "Log file (du): "  $fileName


Write-Output "====================================" | Add-Content $ResultFile2 -Encoding Default
Write-Output "Analysis Results"                     | Add-Content $ResultFile2 -Encoding Default
Write-Output "====================================" | Add-Content $ResultFile2 -Encoding Default

if ($null -eq $file){
    "Error: null array" 
} else {
    Write-Output  $file  | Add-Content $ResultFile2 -Encoding Default
} 

Write-Output "====================================" | Add-Content $ResultFile2 -Encoding Default
Write-Output "Possible Cause"                       | Add-Content $ResultFile2 -Encoding Default
Write-Output "====================================" | Add-Content $ResultFile2 -Encoding Default

$FlgWF1 = 0
$FlgWF2 = 0
$FlgWF3 = 0
$FlgWF4 = 0
$FlgWF5 = 0

for ($i=0; $i -lt 25; $i++){
    # $file[$i].trimstart() -replace("\s", ",$1")
    # $file[$i].trimstart() -split "\s",1
    
    # Work Flow 1: WinSxS
    # Case sensitive�ɔ���
    if ($file[$i] -imatch "c:\\windows\\winsxs"){
        if ($FlgWF1 -eq 0){
            Write-Output ""| Add-Content $ResultFile2 -Encoding Default
            Write-Output "[Possible Cause] WinSxS folder" | Add-Content $ResultFile2 -Encoding Default
            Write-Output "" | Add-Content $ResultFile2 -Encoding Default
            $FlgWF1 = 1
        }
        Write-Output  $file[$i] | Add-Content $ResultFile2 -Encoding Default

    }
    
    # Work Flow 2: Installer
    # Case sensitive�ɔ���
    if ($file[$i] -imatch "c:\\Windows\\installer"){
        if ($FlgWF2 -eq 0){
            Write-Output "" | Add-Content $ResultFile2 -Encoding Default
            Write-Output "[Possible Cause] Installer folder" | Add-Content $ResultFile2 -Encoding Default
            Write-Output "" | Add-Content $ResultFile2 -Encoding Default
            $FlgWF2 = 1
        }
        Write-Output  $file[$i] | Add-Content $ResultFile2 -Encoding Default
    }
    
    # Work Flow 3: IIS log
    if ($file[$i] -imatch "inetpub"){
        if ($FlgWF3 -eq 0){
            Write-Output "" | Add-Content $ResultFile2 -Encoding Default
            Write-Output "[Possible Cause] IIS log folder" | Add-Content $ResultFile2 -Encoding Default
            Write-Output "  Reference:" | Add-Content $ResultFile2 -Encoding Default
            Write-Output "  https://docs.microsoft.com/en-us/iis/manage/provisioning-and-managing-iis/managing-iis-log-file-storage" | Add-Content $ResultFile2 -Encoding Default
            Write-Output "" | Add-Content $ResultFile2 -Encoding Default
            $FlgWF3 = 1
        }
        Write-Output  $file[$i] | Add-Content $ResultFile2 -Encoding Default
    }
    
    # Work Flow 4: WSUS database
    # Case sensitive�ɔ���
    if ($file[$i] -imatch "c:\\Windows\\WID\\Data"){
        if ($FlgWF4 -eq 0){
            Write-Output "" | Add-Content $ResultFile2 -Encoding Default
            Write-Output "[Possible Cause] WSUS database" | Add-Content $ResultFile2 -Encoding Default
            Write-Output "" | Add-Content $ResultFile2 -Encoding Default
            $FlgWF4 = 1
        }
        Write-Output  $file[$i] | Add-Content $ResultFile2 -Encoding Default
    }
    # Write-Output  $file[$i] >> $ResultFile
    
    # Work Flow 5: Azure backup cache
    # Case sensitive�ɔ���
    if ($file[$i] -imatch "c:\\Program Files\\Microsoft Azure Recovery Services Agent\\Scratch"){
        if ($FlgWF5 -eq 0){
            Write-Output "" | Add-Content $ResultFile2 -Encoding Default
            Write-Output "[Possible Cause] Azure backup cache" | Add-Content $ResultFile2 -Encoding Default
            Write-Output "" | Add-Content $ResultFile2 -Encoding Default
            $FlgWF5 = 1
        }
        Write-Output  $file[$i] | Add-Content $ResultFile2 -Encoding Default
    }
    # Write-Output  $file[$i] >> $ResultFile
}


# Fuction Get-DiskUsageInformation
# Open fsutil_queryjournal.txt

# Set File Path For Du
$USNPrivFile = Get-ChildItem $Path -include "*fsutil_queryjournal.txt" -Recurse | ?{ $_.Length -ne $null } | Select-Object Fullname


Function Get-USNJournalInformation{

    $fileName = $USNPrivFile.Fullname
    $file = Get-Content $fileName

    # Show analyze results
    #Write-Output "Log file (USN): " $fileName

    # Work Flow 7: USN jounal
    # Read "next USN"             : 0x000000014e90aae0  << usn queryJounal 
    if ($file[2] -imatch "0x00000ffffffe0000"){
                Write-Output ""                                                  | Add-Content $ResultFile2 -Encoding Default
                Write-Output "[Possible Cause] USN Jounal."                     | Add-Content $ResultFile2 -Encoding Default
                Write-Output "  -> The nuxt usn jounal is over 16 TB (0x00000ffffffe0000)"                 | Add-Content $ResultFile2 -Encoding Default
                Write-Output ""                                                  | Add-Content $ResultFile2 -Encoding Default
                Write-Output $file | Add-Content $ResultFile2 -Encoding Default 
    }
}
Get-USNJournalInformation



